use crate::parser::Operation;

pub struct VM {
    pub idx: usize,
    pub mem: [u32; 10],
}

impl VM {
    pub fn init() -> VM {
        return VM {
            idx: 0,
            mem: [0; 10],
        };
    }
}

pub fn eval(op: &Operation, vm: &VM) {
    match op {
        Operation::Addition(n1, n2) => {
            println!("Addition = {}", n1 + n2);
        }
        Operation::CreateVar(ident) => {}
        _ => {}
    }
}
