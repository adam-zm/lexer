use crate::lexer::Token;
use crate::lexer::TokenType;
use crate::parser::Operation;

mod codegen;
mod lexer;
mod parser;

fn main() -> Result<(), miette::Report> {
    let path = std::env::args().nth(1).expect("No file path given");
    let input = std::fs::read_to_string(path).expect("Should have been able to read file");

    let mut lexer = lexer::Lexer::initialize(&input);
    let mut tokens: Vec<Token> = Vec::new();
    loop {
        let token = lexer.next()?;
        tokens.push(token.clone());
        if token.token_t == TokenType::EOF {
            break;
        }
    }

    let mut ast: Vec<Operation> = Vec::new();
    let mut parser = parser::Parser::initilize(&tokens, &mut ast);
    parser.parse_token()?;
    parser.parse_token()?;

    println!("IR: ");
    for op in &ast {
        match &op {
            Operation::CreateVar(name) => {
                println!("CreateVar {}", name);
            }
            Operation::Addition(a, b) => {
                println!("Addition {} + {}", a, b);
            }
        }
    }
    println!("_________");
    println!("Eval: ");

    codegen::eval(ast.iter().nth(1).unwrap());

    Ok(())
}
